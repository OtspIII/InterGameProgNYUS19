﻿using UnityEngine;

namespace MishasStuff
{

    public struct DLine
    {
        public string Txt;
        public Color C;
        public float Size;

        public DLine(string t)
        {
            Txt = t;
            C = Color.green;
            Size = 10;
        }

        public DLine(string t, Color c, float size = 10)
        {
            Txt = t;
            C = c;
            Size = size;
        }

    }

}