﻿public enum PlayerState{
None=0,
Idle=1,
Walking=2,
Jumping=3,
Dead=4,
Stunned=5
}
