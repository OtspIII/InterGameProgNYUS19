﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using MishasStuff;

public class CameraController : MonoBehaviour
{

	public TextMeshPro Text;
	private float Timer;
	
	public Vector2 Bounds;
	public List<DLine> Script = new List<DLine>();
	
	void Start () {
		Script.Add(new DLine("It was the best of times"));
		Script.Add(new DLine("It was the worst of times",Color.red,100));
		Script.Add(new DLine("It was a time",Color.blue,5));
		Script.Add(new DLine("Specifically, it was tuesday",Color.yellow));
		Script.Add(new DLine("3PM"));
		Script.Add(new DLine("I was at a pie shop"));
		int n = 1;
		int p;
		ChangeNumber(n,out p);
		Debug.Log(n);

	}

	public int ChangeNumber(int n, out int p)
	{
		p = 100;
		return n + 1;
	}
	
//	public int AddNumbers(int a, int[] nums)
//	{
//		int r = a;
//		foreach (int n in nums)
//			r += n;
//		return r;
//	}
	
	void Update ()
	{
		Timer -= Time.deltaTime;
		if (Timer <= 0 && Script.Count > 0)
		{
			Timer = 2;
			Text.text = Script[0].Txt;
			Text.faceColor = Script[0].C;
			Text.fontSizeMax = Script[0].Size;
			Script.RemoveAt(0);
		}

		
		Vector3 pos = transform.position;
		
		//If the player moves too far to the left or right away from me I follow them
		if (transform.position.x > PlayerController.Singleton.transform.position.x + 2)
			pos.x = PlayerController.Singleton.transform.position.x + 2;
		if (transform.position.x < PlayerController.Singleton.transform.position.x - 2)
			pos.x = PlayerController.Singleton.transform.position.x - 2;
		
		//If the player approaches the edge of the map I don't move past the edge
		if (pos.x < Bounds.x)
			pos.x = Bounds.x;
		if (pos.x > Bounds.y)
			pos.x = Bounds.y;

		transform.position = pos;
	}
}

