﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Random = UnityEngine.Random;

public class PlayerController : MonoBehaviour
{

	public Rigidbody2D RB;
	public ParticleSystem Particles;
	public float Speed;
	public float JumpPower;
	public List<GameObject> Touching;
	public static PlayerController Singleton;

	public AudioSource AS;
	public AudioClip Hop;
	public SpriteRenderer Body;

	public PState State;
	public Dictionary<PlayerState,PState> States = new Dictionary<PlayerState, PState>();
	public int HP = 2;
	
	
	
	void Start ()
	{
		PlayerController.Singleton = this;
		//Find our rigidbody and audio right at the start
		RB = GetComponent<Rigidbody2D>();
		AS = GetComponent<AudioSource>();
		AddState(new PState(PlayerState.Idle,Color.cyan));
		AddState(new PState(PlayerState.Walking,Color.red));
		AddState(new PState(PlayerState.Jumping,Color.yellow));
		AddState(new DeadState());
		AddState(new StunnedState());
	}
	
	void Update ()
	{
		if (State == null  || State.InControl)
			Inputs();
		if (State != null)
			State.Run(this);
	}

	void AddState(PState s)
	{
		States.Add(s.State,s);
	}

	public void SetState(PlayerState s)
	{
		if (State != null && State.State == s)
			return;
		if (!States.ContainsKey(s))
		{
			Debug.Log("ATTEMPTED TO USE INVALID STATE: " + s);
			return;
		}
		if (State != null)
			State.OnEnd(this);
		State = States[s];
		State.OnStart(this);
	}

	
	void Inputs()
	{
		//Pull out our old velocity so we can modify it
		Vector3 vel = RB.velocity;
		//If we're hitting keys we move in that direction
		if (Input.GetKey(KeyCode.RightArrow))
		{
			vel.x = Speed;
		}
		else if (Input.GetKey(KeyCode.LeftArrow))
		{
			vel.x = -Speed;
		}
		else //If we're not hitting keys, come to stop
		{
			vel.x = 0;
		}
		
		//Jump, but only if you're touching the ground
		if (Input.GetKeyDown(KeyCode.UpArrow) && Touching.Count > 0)
		{
			vel.y = JumpPower;
			AS.PlayOneShot(Hop);
			Particles.Emit(10);
		}

		//Okay, we've modified our velocity enough--plug it back into the rigidbody
		RB.velocity = vel;

		if (vel.y != 0)
			SetState(PlayerState.Jumping);
		else if (vel.x != 0)
			SetState(PlayerState.Walking);
		else
			SetState(PlayerState.Idle);
	}

	public void TakeDamage()
	{
		HP--;
		if (HP > 0)
			SetState(PlayerState.Stunned);
		else
		{
			SetState(PlayerState.Dead);
		}
	}
	
	void OnCollisionEnter2D(Collision2D other)
	{
		//Keeps track of if we're touching any floor objects
		if (other.gameObject.name == "Floor")
		{
			if (!Touching.Contains(other.gameObject))
				Touching.Add(other.gameObject);
		}

		//Did we bump into an exit?
		ExitController exit = other.gameObject.GetComponent<ExitController>();
		if (exit != null)
		{
			exit.BumpIntoMe(this);
		}
	
		//Did we bump into a monster?
		MonsterController monster = other.gameObject.GetComponent<MonsterController>();
		if (monster != null)
		{
			monster.BumpIntoMe(this);
		}
		
		//Did we bump into a coin?
		CoinController coin = other.gameObject.GetComponent<CoinController>();
		if (coin != null)
		{
			coin.BumpIntoMe(this);
		}
	}
	

	void OnCollisionExit2D(Collision2D other)
	{
		//Tracks when we stop touching floors
		if (other.gameObject.name == "Floor")
		{
			Touching.Remove(other.gameObject);
		}
	}

}

public class PState
{
	public PlayerState State;
	public Color C;
	public bool InControl = true;

	public PState()
	{
	}
	
	public PState(PlayerState ps,Color c)
	{
		State = ps;
		C = c;
	}
	
	public virtual void OnStart(PlayerController c)
	{ }
	
	public virtual void Run(PlayerController c)
	{ }
	
	public virtual void OnEnd(PlayerController c)
	{ }
}

public class DeadState : PState
{
	public DeadState()
	{
		State = PlayerState.Dead;
		C = Color.black;
		InControl = false;
	}

	public override void Run(PlayerController c)
	{
		c.RB.isKinematic = true;
		c.RB.velocity = new Vector2(0,10);
		c.transform.Rotate(0,0,30);
	}
}

public class StunnedState : PState
{
	public float Timer = -999;

	public StunnedState()
	{
		State = PlayerState.Stunned;
		C = Color.gray;
		InControl = false;
	}

	public override void OnStart(PlayerController c)
	{
		base.OnStart(c);
		c.RB.velocity = new Vector2(-5,10);
	}

	public override void Run(PlayerController c)
	{
		if (Timer > -999)
		{
			Timer -= Time.deltaTime;
			if (Timer <= 0)
				c.SetState(PlayerState.Idle);
		}
	}
}
